# CAUL AI — Source-Only Export (for the isolated "Stage B" Emergent app)

This archive is a **source-only** snapshot of the CAUL AI Command Center, intended to seed a
**new, separate, isolated Emergent app** where Stage B can be built and tested against a
**staging** Supabase project using **synthetic data only**. It contains **NO secrets** and
**NO runtime/build artifacts**.

## What is INCLUDED
- `backend/` — FastAPI app (`server.py`, `app/`, `alembic/`, `scripts/`, `tests/`, `requirements.txt`, `alembic.ini`, `pytest.ini`, `.coveragerc`)
- `frontend/` — React app (`src/`, `public/`, `plugins/`, `package.json`, `yarn.lock`, config files)
- `docs/` — all planning/design/spec documents (Stage B, Supabase plan, incident report, etc.)
- `memory/PRD.md` — product requirements
- `.emergent/crons.yml`, `.emergent/emergent.yml` — scheduler/platform config
- Root: `README.md`, `.gitignore`, `design_guidelines.json`, `auth_testing.md`
- `backend/.env.example`, `frontend/.env.example` — **variable NAMES only, no values**

## What is EXCLUDED (deliberately)
- **All secrets:** every `.env` (both `backend/.env` and `frontend/.env`) — fill values via the new app's Secrets panel using the `.env.example` names.
- `.git/`, `.github/` history/CI, `node_modules/`, `postgres_data/` (local DB data),
  `backups/`, `*.sql` schema dumps, `deployer-agent-docs/`, `test_reports/`,
  caches (`__pycache__/`, `.pytest_cache/`, `.ruff_cache/`, `.coverage`), build output.

## How to use in the new isolated Emergent app
1. Unpack this archive into the new app's `/app` root.
2. Recreate env vars from `backend/.env.example` and `frontend/.env.example` via the **Secrets panel** (never commit real values).
3. For a **staging Supabase** rehearsal: set `APP_ENV=staging`, point `STAGING_DATABASE_URL` /
   `STAGING_ADMIN_DATABASE_URL` at the Supabase **Session pooler (port 5432, `sslmode=require`)**,
   run `alembic upgrade head` (admin role), then populate with the built-in synthetic generators
   (`app/seed.py` stub users + `app/usage_synth.py`). No production URLs, no real data.
4. Stage B work (explicit `production` env + fail-fast guards + default-off dev-only flags) is
   specified in `docs/STAGE_B_PRODUCTION_ENV_DESIGN.md`.

## Guarantees
- No credentials, tokens, connection strings, or personal data are present in this export.
- Nothing in this archive connects to or affects the production `caul-impl-gate` deployment.
